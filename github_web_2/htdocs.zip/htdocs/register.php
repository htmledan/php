<?php
include 'config.php';
include 'functions.php';

$id_user = generateUniqueID($conn, "user", "id_user");
session_start();

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $nama = mysqli_real_escape_string($conn, $_POST['nama']);
    $username = mysqli_real_escape_string($conn, $_POST['username']);
    $password = password_hash($_POST['password'], PASSWORD_DEFAULT);
    $level = "user"; 

    $cek = mysqli_query($conn, "SELECT * FROM user WHERE username='$username'");
    
    if (mysqli_num_rows($cek) > 0) {
        echo "<script>alert('Username sudah digunakan!');</script>";
    } else {
        $insert = mysqli_query($conn, 
            "INSERT INTO user (nama, username, password, level)
             VALUES ('$nama', '$username', '$password', '$level')"
        );

        if ($insert) {
            echo "<script>
                    alert('Akun berhasil dibuat! Silakan login.');
                    window.location='login.php';
                  </script>";
            exit;
        } else {
            echo "<script>alert('Gagal Mendaftar!');</script>";
        }
    }
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Register - Toko Amanah</title>
    <link rel="stylesheet" href="css/form_barang.css">

    <style>
        body {
            display: flex;
            flex-direction: column;
            min-height: 100vh;
            margin: 0;
            font-family: Arial, sans-serif;
            background: #f4f4f4;
        }

        header, footer {
            text-align: center;
            padding: 10px;
            background-color: #0077cc;
            color: white;
        }

        main {
            flex: 1;
            display: flex;
            justify-content: center;
            align-items: center;
        }

        .login-box {
            background: white;
            padding: 30px 40px;
            border-radius: 15px;
            box-shadow: 0 0 15px rgba(0,0,0,0.1);
            width: 300px;
        }

        .login-box label {
            display: block;
            margin-top: 10px;
            font-weight: bold;
        }

        .login-box input {
            width: 100%;
            padding: 8px;
            margin-top: 5px;
            border-radius: 5px;
            border: 1px solid #ccc;
        }

        .login-box button {
            width: 100%;
            margin-top: 15px;
            padding: 10px;
            background: #0077cc;
            color: white;
            border: none;
            border-radius: 8px;
            cursor: pointer;
        }

        .login-box button:hover {
            background: #005fa3;
        }

        .login-box p {
            text-align: center;
            margin-top: 12px;
        }
    </style>
</head>
<body>

<header>
    <h1>Register Toko Amanah</h1>
</header>

<main>
    <div class="login-box">
        <h2 style="text-align:center;">Daftar User Baru</h2>

        <form method="POST">
            <label>Nama:</label>
            <input type="text" name="nama" required
                   oninvalid="this.setCustomValidity('Tolong isi form ini!')"
       oninput="this.setCustomValidity('')"><br><br>

            <label>Username:</label>
            <input type="text" name="username" required
                   oninvalid="this.setCustomValidity('Tolong isi form ini!')"
       oninput="this.setCustomValidity('')"><br><br>

            <label>Password:</label>
            <input type="password" name="password" required
                   oninvalid="this.setCustomValidity('Tolong isi form ini!')"
       oninput="this.setCustomValidity('')"><br><br>

            <button type="submit">Daftar</button>
        </form>

        <p>Sudah punya akun? <a href="login.php">Login di sini</a></p>
    </div>
</main>

<footer>
    &copy; <?php echo date("Y"); ?> Toko Amanah. All rights reserved.
</footer>

</body>
</html>

<?php
include 'config.php';

session_start();

// Cek login
if (!isset($_SESSION['username'])) {
    header("Location: login.php");
    exit;
}

// Cek level admin only
if ($_SESSION['level'] !== 'admin') {
    header("Location: beranda.php"); // user biasa akan dilempar ke beranda
    exit;
}
?>


<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login - Toko Amanah</title>
    <link rel="stylesheet" href="css/form_barang.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css"> 


    <style> element.heading {
        min-height: 100vh;
        display: grid;
        grid-template-rows: auto max-content;
        grid-template-columns: 100%;
        --app-shell-transition-duration: 200ms;
        --app-shell-transition-timing-function: 
        ease;
        
}</style>
<style>
        
        body {
            display: flex;
            flex-direction: column;
            min-height: 100vh;
            margin: 0;
            font-family: Arial, sans-serif;
            background: #f4f4f4;
        }

        header, footer {
            text-align: center;
            padding: 10px;
            background-color: #0077cc;
            color: white;
        }

        main {
            flex: 1;
            display: flex;
            justify-content: center;
            align-items: center;
        }

        .login-box {
            background: white;
            padding: 30px 40px;
            border-radius: 15px;
            box-shadow: 0 0 15px rgba(0,0,0,0.1);
            width: 300px;
        }

        .login-box label {
            display: block;
            margin-top: 10px;
            font-weight: bold;
        }

        .login-box input {
            width: 100%;
            padding: 8px;
            margin-top: 5px;
            border-radius: 5px;
            border: 1px solid #ccc;
        }

        .login-box button {
            width: 100%;
            margin-top: 15px;
            padding: 10px;
            background: #0077cc;
            color: white;
            border: none;
            border-radius: 8px;
            cursor: pointer;
        }

        .login-box button:hover {
            background: #005fa3;
        }

        .welcome {
            text-align: center;
            margin-bottom: 20px;
        }

        footer {
            font-size: 14px;
        }

        .top-banner {
        width: 100%;
        height: 200px; /* sesuaikan tinggi gambar */
        overflow: hidden;
        position: relative;
        transition: opacity 0.5s ease, transform 0.5s ease;
        }

        .top-banner img {
            width: 100%;
            height: 100%;
            object-fit: cover; /* biar gambar selalu rapi */
            display: block;
        }

    </style>
</head>

</head>

<body>
    <div class="top-banner" id="topBanner">
    <img src="toko-a.webp" alt="Toko Amanah">
</div>

 <header>
        <h1>Dashboard - Toko Amanah</h1>
    </header>
 <div class="wrapper">


<nav>
      <a href="home.html"><i class="fas fa-home"></i></a><br>
      <a href="profile.html"><i class="fas fa-user"></i></a><br/>
      <a href="contact.html"><i class="fas fa-envelope"></i></a>
        <div class="search-box">
            <input type="text" placeholder="Pencarian">
        </div>
    </nav>


    <h2>Selamat Datang di dashboard, <?= $_SESSION['username']; ?> </h2>
    <p>Level: <?= $_SESSION['level']; ?></p>

    <nav>
<div>
<a href="daftar_barang.php" class="btn">Daftar Barang</a>
</div>

<div>
<a href="daftar_transaksi.php" class="btn">Daftar Transaksi</a>
</div>



    </nav>

    <a href="logout.php">Logout</a>
</body>
</html>

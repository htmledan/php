<?php
include 'config.php';
session_start();

if (!isset($_SESSION['username'])) {
    header("Location: login.php");
    exit();
}

$username = $_SESSION['username'];

if ($_SERVER['REQUEST_METHOD'] == 'POST') {

    $nama   = $_POST['nama'];
    $email  = $_POST['email'];
    $hp     = $_POST['hp'];
    $alamat = $_POST['alamat'];
    $tanggal = date("Y-m-d");

    // Upload Foto
    $dir = "uploadmember/";
    $fotoName = time() . "_" . basename($_FILES["foto"]["name"]);
    $target = $dir . $fotoName;

    move_uploaded_file($_FILES["foto"]["tmp_name"], $target);

    // Insert Database
    $sql = "INSERT INTO member (username, nama, email, hp, alamat, foto, tanggal_daftar)
            VALUES ('$username', '$nama', '$email', '$hp', '$alamat', '$fotoName', '$tanggal')";
    mysqli_query($conn, $sql);

    // ID terakhir
    $id_member = mysqli_insert_id($conn);

    // SESSION untuk profildiri
    $_SESSION['member_id'] = $id_member;
    $_SESSION['nama_member'] = $nama;
    $_SESSION['email_member'] = $email;
    $_SESSION['hp_member'] = $hp;
    $_SESSION['alamat_member'] = $alamat;
    $_SESSION['foto_member'] = $fotoName;
    $_SESSION['tanggal_daftar'] = $tanggal;

    header("Location: profildiri.php");
    exit();
}
?>

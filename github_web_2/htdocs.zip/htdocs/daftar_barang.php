<?php
include 'config.php';
$result = mysqli_query($conn, "SELECT * FROM barang");
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Daftar Barang - Toko Amanah</title>
    <link rel="stylesheet" href="css/style.css"> <!-- ✅ Panggil CSS eksternal -->
</head>

<body>
    <header>
        <h1>Toko Amanah (ADMIN)</h1>
        <h2>Daftar Barang</h2>
    </header>

    <nav>
        <div>
            <span class="icon">🏠</span>
            <span class="icon">📖</span>
            <span class="icon">📞</span>
        </div>
        <div class="search-box">
            <input type="text" placeholder="Pencarian">
        </div>
    </nav>

    <div class="container">
        <h2>Welcome to Web Amanah!</h2>
        <p>Pesan barang atau takeaway barang!</p>

        <table>
            <tr>
                <th>No</th>
                <th>Nama Barang</th>
                <th>Harga</th>
                <th>Stok</th>
            </tr>
            <?php
            $no = 1;
            while ($row = mysqli_fetch_assoc($result)) {
                echo "<tr>
                    <td>{$no}</td>
                    <td>{$row['nama_barang']}</td>
                    <td>Rp " . number_format($row['harga'], 0, ',', '.') . "</td>
                    <td>{$row['stok']}</td>
                    <td>
                <a href='hapus_barang.php?id={$row['id_barang']}' onclick=\"return confirm('Yakin ingin menghapus data ini?')\">🗑️ Hapus</a>
            </td>
                </tr>";
                $no++;
            }
            ?>
        </table>

        <a href='form_barang.php'>➕ Tambah Barang Baru</a>
        <a href='dashboard.php' class='btn-back'>⬅ Kembali ke Dashboard</a>
    </div>
</body>
</html>

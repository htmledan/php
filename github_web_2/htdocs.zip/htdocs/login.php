<?php
include 'config.php';
session_start();

if (isset($_POST['login'])) {

    // Ambil input
    $username = mysqli_real_escape_string($conn, $_POST['username']);
    $password = $_POST['password'];

    // Cari user berdasarkan username saja
    $query = "SELECT * FROM user WHERE username='$username' LIMIT 1";
    $result = mysqli_query($conn, $query);
    $data = mysqli_fetch_assoc($result);

    if ($data) {

        // Cek password HASH
        if (password_verify($password, $data['password'])) {

            // simpan session
            $_SESSION['username'] = $data['username'];
            $_SESSION['level']    = $data['level'];
            $_SESSION['name']      = $data['name'];
            $_SESSION['image_url'] = $data['image_url'];
            $_SESSION['level']     = $data['level'];

            // Arahkan sesuai level
            switch ($data['level']) {
                case 'admin':
                    header("Location: dashboard.php");
                    break;

                case 'kasir':
                    header("Location: kasir_home.php");
                    break;

                case 'user':
                    header("Location: beranda.php");
                    break;

                case 'pemilik':
                    header("Location: pemilik_home.php"); 
                    break;

                default:
                    echo "<script>alert('Level tidak dikenali!');</script>";
            }
            exit();
        } else {
            echo "<script>alert('Password salah!');</script>";
        }

    } else {
        echo "<script>alert('Username tidak ditemukan!');</script>";
    }
}
?>



<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login - Toko Amanah</title>
    <link rel="stylesheet" href="css/form_barang.css">
    <style>
        
        body {
            display: flex;
            flex-direction: column;
            min-height: 100vh;
            margin: 0;
            font-family: Arial, sans-serif;
            background-image: url ('toko-a.webp');
            background-repeat: no-repeat;
            background-size: cover;
        }
        
        header, footer {
            text-align: center;
            padding: 10px;
            background-color: #0077cc;
            color: white;
        }

        main {
            flex: 1;
            display: flex;
            justify-content: center;
            align-items: center;
        }

        .login-box {
            background: white;
            padding: 30px 40px;
            border-radius: 15px;
            box-shadow: 0 0 15px rgba(0,0,0,0.1);
            width: 300px;
        }

        .login-box label {
            display: block;
            margin-top: 10px;
            font-weight: bold;
        }

        .login-box input {
            width: 100%;
            padding: 8px;
            margin-top: 5px;
            border-radius: 5px;
            border: 1px solid #ccc;
        }

        .login-box button {
            width: 100%;
            margin-top: 15px;
            padding: 10px;
            background: #0077cc;
            color: white;
            border: none;
            border-radius: 8px;
            cursor: pointer;
        }

        .login-box button:hover {
            background: #005fa3;
        }

        .welcome {
            text-align: center;
            margin-bottom: 20px;
        }

        footer {
            font-size: 14px;
        }
    </style>
</head>
<body>
    

    <header>
        <h1>LOGIN</h1>
    </header>

    <main>
        
</div>
        <div class="login-box">
            <div class="welcome">
                <h2>Welcome to Web Amanah!</h2>
                <p>Pesan barang atau takeaway barang!</p>
            </div>

            <form method="POST">
                <label>Username</label>
                <input type="text" name="username" required
                       oninvalid="this.setCustomValidity('Tolong isi form ini!')"
       oninput="this.setCustomValidity('')"><br><br>

                <label>Password</label>
                <input type="password" name="password" required
                       oninvalid="this.setCustomValidity('Tolong isi form ini!')"
       oninput="this.setCustomValidity('')"><br><br>

                <div class="show-password">
                    <input type="checkbox" id="togglePassword">
                    <label for="togglePassword">Show Password</label>
                </div>

                <button type="submit" name="login">Login</button>
            </form>
            <p style="text-align:center; margin-top:15px;">
    			Belum punya akun? <a href="register.php">Daftar di sini</a>
		</p>
            </div>
    </main>

    <footer>
        &copy; <?php echo date("Y"); ?> Toko Amanah. All rights reserved.
    </footer>

    <script>
        // Toggle show/hide password
        const toggle = document.getElementById("togglePassword");
        const pass = document.querySelector('input[name="password"]');
        toggle.addEventListener("change", () => {
            pass.type = toggle.checked ? "text" : "password";
        });
    </script>
</body>
</html>

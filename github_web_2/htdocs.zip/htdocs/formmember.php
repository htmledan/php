<?php
session_start();
if (!isset($_SESSION['username'])) {
    header("Location: login.php");
    exit();

if ($insert) {
            echo "<script>
                    alert('Akun berhasil dibuat! Silakan login.');
                    window.location='login.php';
                  </script>";
            exit;
        } else {
            echo "<script>alert('Gagal Mendaftar!');</script>";
        }
    }
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Daftar Member</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background: #eef5ff;
            margin: 0;
            padding: 0;
        }
        .container {
            max-width: 500px;
            margin: 40px auto;
            background: white;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 0 10px rgba(0,0,0,0.1);
        }
        h2 {
            text-align: center;
            color: #0077cc;
        }
        input, textarea {
            width: 100%;
            padding: 10px;
            margin: 8px 0;
            border: 1px solid #aaa;
            border-radius: 6px;
        }
        input[type="submit"] {
            background: #0077cc;
            color: white;
            cursor: pointer;
            font-weight: bold;
        }
        input[type="submit"]:hover {
            background: #005fa3;
        }
        label {
            font-weight: bold;
        }
    </style>
</head>
<body>

<div class="container">
    <h2>Daftar Member</h2>

    <form action="processmember.php" method="POST" enctype="multipart/form-data">

        <label>Nama Lengkap</label>
        <input type="text" name="nama" required>

        <label>Email</label>
        <input type="email" name="email" required>

        <label>No. HP</label>
        <input type="text" name="hp" required>

        <label>Alamat</label>
        <textarea name="alamat" required></textarea>

        <label>Foto Profil</label>
        <input type="file" name="foto" accept="image/*" required>

        <input type="submit" value="Daftar Sekarang">
    </form>
</div>

</body>
</html>

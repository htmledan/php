<?php

function generateID($prefix = '') {
    return $prefix . strtoupper(substr(bin2hex(random_bytes(5)), 0, 10));
}

function generateUniqueID($conn, $table, $column) {
    do {
        $id = strtoupper(substr(bin2hex(random_bytes(5)), 0, 10));
        $check = mysqli_query($conn, "SELECT $column FROM $table WHERE $column='$id'");
    } while (mysqli_num_rows($check) > 0);

    return $id;
}

?>

<?php
include 'config.php'; // pastiin file ini sesuai ya

error_reporting(E_ALL);
ini_set('display_errors', 1);

// Ambil data dari tabel transaksi
$query = "SELECT * FROM transaksi ORDER BY id_transaksi DESC";
$result = mysqli_query($conn, $query);

if (!$result) {
    die("Query error: " . mysqli_error($conn));
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Daftar Transaksi - Toko Amanah</title>
    <link rel="stylesheet" href="css/style.css">
     <style>
        
        body {
            display: flex;
            flex-direction: column;
            min-height: 100vh;
            margin: 0;
            font-family: Arial, sans-serif;
            background: #f4f4f4;
        }

        header, footer {
            text-align: center;
            padding: 10px;
            background-color: #0077cc;
            color: white;
        }

        main {
            flex: 1;
            display: flex;
            justify-content: center;
            align-items: center;
        }


    </style>
</head>
<body>
    <header>
        <h1>Toko Amanah (ADMIN)</h1>
        <h2>Daftar Transaksi</h2>
    </header>

    <nav>
        <div>
            <a href="dashboard.php" class="icon">🏠</a>
            <a href="daftar_barang.php" class="icon">📦</a>
            <a href="transaksi.php" class="icon">💰</a>
        </div>
        <div class="search-box">
            <input type="text" placeholder="Cari transaksi...">
        </div>
    </nav>

   
        <h3>Data Transaksi</h3>
        <table border="1" cellpadding="10" cellspacing="0">
            <tr>
                <th>No</th>
                <th>ID Transaksi</th>
                <th>Tanggal</th>
                <th>ID User</th>
                <th>ID Pelanggan</th>
                <th>total_harga</th>
                <th>Aksi</th>
            </tr>

            <?php
            $no = 1;
            if (mysqli_num_rows($result) > 0) {
                while ($row = mysqli_fetch_assoc($result)) {
                    echo "<tr>";
                    echo "<td>" . $no++ . "</td>";
                    echo "<td>" . $row['id_transaksi'] . "</td>";
                    echo "<td>" . $row['tanggal'] . "</td>";
                    echo "<td>" . $row['id_user'] . "</td>";
                    echo "<td>" . $row['id_pelanggan'] . "</td>";
        
                    echo "<td>Rp " . number_format($row['total_harga'], 0, ',', '.') . "</td>";
                    echo "<td>
                            <a href='detail_transaksi.php?id=" . $row['id_transaksi'] . "'>Detail</a> 
                            <a href='hapus_transaksi.php?id=" . $row['id_transaksi'] . "' onclick=\"return confirm('Yakin ingin menghapus transaksi ini?')\"> Hapus</a>
                          </td>";
                    echo "</tr>";
                }
            } else {
                echo "<tr><td colspan='5' align='center'>Belum ada transaksi</td></tr>";
            }
            ?>
        </table>

        <br>
        <a href="tambah_transaksi.php">➕ Tambah Transaksi Baru</a>
     <a href='dashboard.php' class='btn-back'>⬅ Kembali ke Dashboard</a>
    </div>
</body>
</html>


<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

$host = "sql305.infinityfree.com";
$user = "if0_40394423";
$pass = "pijaygcc";
$db   = "if0_40394423_koneksi_toko";

$conn = mysqli_connect($host, $user, $pass, $db);

$config = $conn;   // <-- pakai $config atau $conn

if (!$conn) {
    die("Koneksi gagal: " . mysqli_connect_error());
}
?>

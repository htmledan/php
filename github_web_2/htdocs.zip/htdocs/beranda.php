<?php
include 'config.php';
session_start();

// Cek login
if (!isset($_SESSION['level'])) {
    header("Location: login.php");
    exit();
}

// Cek level user
if ($_SESSION['level'] !== 'user') {
    header("Location: dashboard.php");
    exit();
}
//bagian fotoprofil
$profil = mysqli_fetch_assoc(mysqli_query($conn, 
    "SELECT foto FROM member ORDER BY id DESC LIMIT 1"
));
// Ambil data barang
$sql = "SELECT * FROM barang ORDER BY nama_barang ASC";
$result = mysqli_query($conn, $sql);
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
     <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Beranda - Toko Amanah</title>
    <link rel="stylesheet" href="css/form_barang.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css"> 

    <style> element.heading {
        min-height: 100vh;
        display: grid;
        grid-template-rows: auto max-content;
        grid-template-columns: 100%;
        --app-shell-transition-duration: 200ms;
        --app-shell-transition-timing-function: 
        ease;
        
}</style>
    <style>
         body {
            display: flex;
            flex-direction: column;
            min-height: 100vh;
            margin: 0;
            font-family: Arial, sans-serif;
            background: #f4f4f4;
        }

        header, footer {
            text-align: center;
            padding: 10px;
            background-color: #0077cc;
            color: white;
        }

        main {
            flex: 1;
            display: flex;
            justify-content: center;
            align-items: center;
        }

        .login-box {
            background: white;
            padding: 30px 40px;
            border-radius: 15px;
            box-shadow: 0 0 15px rgba(0,0,0,0.1);
            width: 300px;
        }

        .login-box label {
            display: block;
            margin-top: 10px;
            font-weight: bold;
        }

        .login-box input {
            width: 100%;
            padding: 8px;
            margin-top: 5px;
            border-radius: 5px;
            border: 1px solid #ccc;
        }

        .login-box button {
            width: 100%;
            margin-top: 15px;
            padding: 10px;
            background: #0077cc;
            color: white;
            border: none;
            border-radius: 8px;
            cursor: pointer;
        }

        .login-box button:hover {
            background: #005fa3;
        }

        .welcome {
            text-align: center;
            margin-bottom: 20px;
        }

        footer {
            font-size: 14px;
        }

        .top-banner {
        width: 100%;
        height: 200px; /* sesuaikan tinggi gambar */
        overflow: hidden;
        position: relative;
        transition: opacity 0.5s ease, transform 0.5s ease;
        }

        .top-banner img {
            width: 100%;
            height: 100%;
            object-fit: cover; /* biar gambar selalu rapi */
            display: block;
        }
        body {
            font-family: Arial, sans-serif;
            background: #eef5ff;
            margin: 0;
        }
        header {
            background: #0077cc;
            padding: 15px;
            color: white;
            text-align: center;
        }
        .logout {
            float: right;
            background: red;
            padding: 8px 12px;
            color: white;
            border-radius: 5px;
            text-decoration: none;
        }
        .logout:hover {
            background: darkred;
        }
        .container {
            width: 90%;
            margin: 30px auto;
        }
        .grid {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(220px, 1fr));
            gap: 20px;
        }
        .card {
            background: white;
            border-radius: 15px;
            padding: 15px;
            box-shadow: 0 0 10px rgba(0,0,0,0.1);
            text-align: center;
        }
        .card img {
            width: 100%;
            height: 150px;
            object-fit: cover;
            border-radius: 10px;
            margin-bottom: 10px;
        }
        .harga {
            color: green;
            font-weight: bold;
            margin-top: 5px;
        }
         .top-banner {
        width: 100%;
        height: 200px; /* sesuaikan tinggi gambar */
        overflow: hidden;
        position: relative;
        transition: opacity 0.5s ease, transform 0.5s ease;
        }

        .top-banner img {
            width: 100%;
            height: 100%;
            object-fit: cover; /* biar gambar selalu rapi */
            display: block;
        }
        .profil-icon {
    width: 45px;
    height: 45px;
    border-radius: 50%;
    object-fit: cover;
    border: 2px solid #0077cc;
    margin-top: 10px;
    cursor: pointer;
    transition: 0.2s;
}

.profil-icon:hover {
    transform: scale(1.05);
}

    </style>
</head>
<body>
 	<div class="top-banner" id="topBanner">
    <img src="toko-a.webp" alt="Toko Amanah">
	</div>
<header>
    <h1>Selamat Datang, <?= $_SESSION['username']; ?> Di Beranda</h1>
    <a class="logout" href="logout.php">Logout</a>
</header>
<div class="wrapper">
<nav>
      <a href="formmember.php">Daftar Member</a>
      <a href="home.html"><i class="fas fa-home"></i></a><br>
      <a href="profile.html"><i class="fas fa-user"></i></a><br/>
      <a href="contact.html"><i class="fas fa-envelope"></i></a>
        <div class="search-box">
           
            <input type="text" placeholder="Pencarian">
        </div>
    </nav>
<div class="container">
    <h2>Daftar Barang</h2>

    <div class="grid">

        <?php while ($row = mysqli_fetch_assoc($result)) : ?>

            <div class="card">
                <?php
                    // Ambil nama file gambar dari kolom img_url
                    $file = "uploads/" . $row['img_url'];

                    // Jika file tidak ditemukan atau kosong, pakai gambar default
                    $foto = (!empty($row['img_url']) && file_exists($file)) 
                            ? $file 
                            : "uploads/noimage.png";
                ?>

           <a href="detail.php?id=<?= $row['id_barang']; ?>">
                    <img src="<?= $foto ?>" alt="<?= 		htmlspecialchars($row['nama_barang']); ?>">
                </a>

                <h3><?= htmlspecialchars($row['nama_barang']); ?></h3>
                <p>Stok: <?= $row['stok']; ?></p>
                <p class="harga">Rp <?= number_format($row['harga'], 0, ',', '.'); ?></p>
            </div>

        <?php endwhile; ?>

    </div>
</div>

</body>
</html>

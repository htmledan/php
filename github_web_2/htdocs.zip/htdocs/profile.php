<?php
include 'config.php';
session_start();

$id_member = $_SESSION['id_member']; // ID dari login

$query = mysqli_query($conn, "SELECT * FROM member WHERE id='$id_member'");
$data = mysqli_fetch_assoc($query);
?>

<h2>Profil Saya</h2>

<img src="uploads/<?= $data['foto']; ?>" 
     alt="Foto Profil" 
     width="120" height="120" 
     style="border-radius: 50%;">

<p><strong>Nama:</strong> <?= $data['nama']; ?></p>
<p><strong>Username:</strong> <?= $data['username']; ?></p>
<p><strong>Email:</strong> <?= $data['email']; ?></p>
<p><strong>No HP:</strong> <?= $data['hp']; ?></p>
<p><strong>Alamat:</strong> <?= $data['alamat']; ?></p>
<p><strong>Tanggal Daftar:</strong> <?= $data['tanggal_daftar']; ?></p>

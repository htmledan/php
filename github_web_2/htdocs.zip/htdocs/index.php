<?php
include 'config.php';

header("Location: dashboard.php");
exit;
?>

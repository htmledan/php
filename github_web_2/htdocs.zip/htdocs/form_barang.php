<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);
include 'config.php';

?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Tambah Barang - Toko Amanah</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    
     <header>
        <h1>Toko Amanah (ADMIN)</h1>
        <h2>Tambah Barang Baru</h2>
    </header>

    <nav>
        <div>
            <span class="icon">🏠</span>
            <span class="icon">📖</span>
            <span class="icon">📞</span>
        </div>
        <div class="search-box">
            <input type="text" placeholder="Pencarian">
        </div>
    </nav>

    <div class="container">
        <div class="welcome">
            <h2>Welcome to Web Amanah!</h2>
            <p>Pesan barang atau takeaway barang!</p>
        </div>

   <form action="simpan_barang.php" method="post" enctype="multipart/form-data">
    <label>Nama Barang:</label><br>
    <input type="text" name="nama_barang" required><br><br>

    <label>Harga:</label><br>
    <input type="number" name="harga" required><br><br>

    <label>Stok:</label><br>
    <input type="number" name="stok" required><br><br>

    <label>Gambar Barang:</label><br>
    <input type="file" name="gambar" accept="image/*"><br><br>

    <button type="submit">Simpan</button>
</form>


    <br><a href="daftar_barang.php">Lihat Daftar Barang</a>
</body>
</html>


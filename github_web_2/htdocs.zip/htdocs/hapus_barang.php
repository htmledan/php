
<?php
include 'koneksi.php';

if (isset($_GET['id'])) {
    $id = $_GET['id'];

    // Hapus data dari database
    $query = "DELETE FROM barang WHERE id_barang = '$id'";
    $result = mysqli_query($conn, $query);

    if ($result) {
        // Kalau sukses, balik ke daftar_barang.php
        header("Location: daftar_barang.php");
        exit;
    } else {
        echo "Gagal menghapus data: " . mysqli_error($conn);
    }
} else {
    echo "ID barang tidak ditemukan!";
}
?>

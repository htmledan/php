<?php
include 'config.php';

$id = $_GET['id'];
$sql = "SELECT * FROM barang WHERE id_barang = $id LIMIT 1";
$result = mysqli_query($conn, $sql);
$data = mysqli_fetch_assoc($result);
?>

<!DOCTYPE html>
<html>
<head>
    <title>Detail Barang</title>
</head>
<body>

<h2><?= $data['nama_barang']; ?></h2>
<img src="uploads/<?= $data['img_url']; ?>" width="300">
<p>Harga: <?= number_format($data['harga']); ?></p>
<p>Stok: <?= $data['stok']; ?></p>

<a href="beranda.php">← Kembali</a>

</body>
</html>

<?php
include 'config.php';
session_start();

// Kalau belum ada session member → redirect ke formmember
if (!isset($_SESSION['member_id'])) {
    header("Location: formmember.php");
    exit();
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Profil Member</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background: #eef5ff;
            margin: 0;
            padding: 0;
        }
        header {
            background: #0077cc;
            padding: 15px;
            color: white;
            text-align: center;
        }
        .container {
            max-width: 500px;
            background: white;
            margin: 30px auto;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 0 10px rgba(0,0,0,0.1);
            text-align: center;
        }
        .profile-img {
            width: 140px;
            height: 140px;
            border-radius: 50%;
            object-fit: cover;
            border: 3px solid #0077cc;
        }
        h2 {
            margin-top: 10px;
            color: #0077cc;
        }
        .info {
            text-align: left;
            margin-top: 20px;
        }
        .info p {
            font-size: 16px;
            margin: 8px 0;
        }
        a.button {
            display: inline-block;
            margin-top: 20px;
            padding: 10px 20px;
            background: #0077cc;
            color: white;
            text-decoration: none;
            border-radius: 6px;
        }
        a.button:hover {
            background: #005fa3;
        }
    </style>
</head>
<body>

<header>
    <h1>Profil Member</h1>
</header>

<div class="container">

    <!-- FOTO PROFIL -->
    <?php  
        $foto = isset($_SESSION['foto_member']) ? $_SESSION['foto_member'] : "defaultprofile.png";
    ?>
    <img src="uploadmember/<?php echo $foto; ?>" class="profile-img" alt="Foto Profil">

    <h2><?php echo $_SESSION['nama_member']; ?></h2>

    <div class="info">
        <p><strong>Email:</strong> <?php echo $_SESSION['email_member']; ?></p>
        <p><strong>No. HP:</strong> <?php echo $_SESSION['hp_member']; ?></p>
        <p><strong>Alamat:</strong> <?php echo $_SESSION['alamat_member']; ?></p>
        <p><strong>Member Sejak:</strong> <?php echo $_SESSION['tanggal_daftar']; ?></p>
    </div>

    <a class="button" href="beranda.php">Kembali ke Beranda</a>
</div>

</body>
</html>
